package com.capstore.service;

import java.util.List;

import com.capstore.bean.Category;

import com.capstore.bean.Product;

public interface IProductService {
	Category addCategory(Category category);

	Category updateCategory(Category category);
	
	/*
	 * Author :- Pradnya Gaikwad 173579
	 * version:- 1.0.1
	 */

	// fetch similar product by type
	public List<Product> findByname(String name);

	//
	String deleteCategory(int catId);

	Product addproduct(Product product, int catId);

	Iterable<Category> getAllCategory();

	Iterable<Product> getAllProduct();

}
