package com.capstore.service;

import java.util.ArrayList;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import com.capstore.bean.Category;

import com.capstore.bean.Product;
import com.capstore.repo.CategoryRepo;

import com.capstore.repo.ProductRepo;

@Service
@Transactional
public class ProductServiceImpl implements IProductService {
	@Autowired
	CategoryRepo catRepo;

	@Autowired
	ProductRepo prodRepo;

	public Category addCategory(Category category) {
		return catRepo.save(category);

	}

	public Category updateCategory(Category category) {
		return catRepo.save(category);
	}

	public String deleteCategory(int catId) {
		try {
			catRepo.deleteById(catId);
			return "Category deleted";
		} catch (EmptyResultDataAccessException e) {
			throw new EmptyResultDataAccessException("No Category Found To delete", catId);
		}
	}

	public Product addproduct(Product product, int catId) {
		Category cat = catRepo.findById(catId).get();
		product.setCategory(cat);
		return prodRepo.save(product);
	}

	public Product updateProduct(Product product, int catId) {
		Category cat = catRepo.findById(catId).get();
		product.setCategory(cat);
		return prodRepo.save(product);
	}

	public String deleteProduct(int productId) {
		try {
			prodRepo.deleteById(productId);
			return "Product deleted";
		} catch (EmptyResultDataAccessException e) {
			throw new EmptyResultDataAccessException("No Product Found To delete", productId);
		}
	}

	public Iterable<Category> getAllCategory() {
		return catRepo.findAll();
	}

	public Iterable<Product> getAllProduct() {
		Iterable<Product> prods = prodRepo.findAll();
		for (Product product : prods) {
			System.out.println(product.getCategory());
		}
		return prods;
	}
	
	/*
	 * Author :- Pradnya Gaikwad 173579
	 * version:- 1.0.1
	 */

	// fetch similar product by category name
	@Override
	public List<Product> findByname(String name) {
		Iterable<Category> category = catRepo.findByname(name);
		List<Product> products = new ArrayList<Product>();
		for (Category cat : category) {
			products.addAll(cat.getProduct());
		}
		return products;
	}

}
