import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SimilarProductComponent } from './similar-product/similar-product.component';

const routes: Routes = [
  { path: 'similar-product', component: SimilarProductComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
